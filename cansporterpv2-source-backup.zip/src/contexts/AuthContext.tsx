import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { logActivity } from '@/lib/audit';

interface AppUser {
  id: string;
  user_id: string;
  full_name: string;
  department_id: string | null;
  designation: string | null;
  is_active: boolean;
  last_login: string | null;
  // Distributor Order Management: which distributor this user belongs to.
  // NULL for company staff (super_admin/admin/etc.); set for distributor users.
  distributor_id: string | null;
  // Self-service profile fields (Profile / Account Settings pages).
  phone?: string | null;
  email?: string | null;
  avatar_url?: string | null;
  created_at?: string | null;
}

interface UserRole {
  role: 'super_admin' | 'admin' | 'manager' | 'supervisor' | 'operator' | 'viewer' | 'operational_manager' | 'qa_manager' | 'maintenance_manager' | 'sales_executive' | 'order_management' | 'floor_incharge' | 'private_label_distributor' | 'private_label_manager' | 'private_label_officer' | 'private_label_viewer' | 'pettycash_handler' | 'store_operator' | 'project_manager' | 'online_sales_packing' | 'online_sales_admin' | 'online_sales_manager' | 'online_sales_agent' | 'accounting_poster' | 'accounting_officer' | 'accounting_manager' | 'billing_officer' | 'purchase_officer' | 'purchase_manager' | 'purchase_qc_inspector' | 'dispatch_operator' | 'sales_order_manager' | 'production_operator' | 'closing_data_poster' | 'distributor_sales' | 'distributor_manager' | 'distributor_admin' | 'labour_productivity_approver' | 'labour_productivity_poster' | 'labour_productivity_viewer' | 'export_manager' | 'export_officer' | 'export_viewer' | 'master_data_manager' | 'master_data_officer' | 'master_data_viewer' | 'hr_manager' | 'hr_officer' | 'hr_viewer' | 'wip_manager' | 'wip_officer' | 'wip_viewer' | 'rejections_manager' | 'rejections_officer' | 'rejections_viewer' | 'quality_score_manager' | 'quality_score_officer' | 'quality_score_viewer' |'performance_manager' | 'performance_officer' | 'performance_viewer' | 'floor_inventory_manager' | 'floor_inventory_officer' | 'floor_inventory_viewer' | 'fixed_assets_manager' | 'fixed_assets_officer' | 'fixed_assets_viewer' | 'five_s_manager' | 'five_s_officer' | 'five_s_viewer' | 'hourly_production_manager' | 'hourly_production_officer' | 'hourly_production_viewer' | 'rd_manager' | 'rd_officer' | 'rd_viewer' | 'crm_manager' | 'crm_officer' | 'crm_viewer' | 'marketing_manager' | 'marketing_officer' | 'marketing_viewer' | 'projects_officer' | 'projects_viewer' | 'qa_officer' | 'qa_viewer' | 'maintenance_officer' | 'maintenance_viewer' | 'expenses_manager' | 'expenses_officer' | 'expenses_viewer' | 'material_consumption_manager' | 'material_consumption_officer' | 'material_consumption_viewer' | 'machine_monitor_manager' | 'machine_monitor_officer' | 'machine_monitor_viewer' | 'qa_inspector' | 'qa_super_manager' | 'helpdesk_manager' | 'projects_super_manager' | 'gate_pass_manager' | 'gate_pass_officer' | 'gate_pass_viewer' | 'gate_security' | 'gate_pass_sample_manager' | 'gate_pass_returnable_manager' | 'gate_pass_jobwork_manager' | 'gate_pass_scrap_manager' | 'labour_gate_pass_approver' | 'staff_gate_pass_approver' | 'labour_attendance_delete_approver' | 'production_manager' | 'production_officer' | 'production_viewer' | 'store_pass_manager' | 'store_pass_officer' | 'store_pass_viewer' | 'dispatch_planner_manager' | 'dispatch_planner_officer' | 'dispatch_planner_viewer' | 'pr_office_officer' | 'pr_office_approver' | 'pr_raw_material_officer' | 'pr_raw_material_approver' | 'pr_production_officer' | 'pr_production_approver' | 'pr_spares_officer' | 'pr_spares_approver' | 'production_coordinator' | 'facilities_manager' | 'facilities_officer' | 'facilities_viewer' | 'facilities_technician' | 'cleaning_supervisor';
}

// Per-module access tiers. Every module that had no dedicated role of its own gets the
// same three-tier set (identical in shape to the Labour Productivity tiers above/below):
//   <prefix>_manager → view / create / edit / approve   (delete stays with super admin)
//   <prefix>_officer → view / create / edit
//   <prefix>_viewer  → view only
// Each tier is scoped to its own module (+ the dashboard shell), so a user can hold
// several of them at once and receives the UNION of those module scopes — that is what
// makes "many roles on one user" work without touching per-user module permissions.
type ModuleTier = 'manager' | 'officer' | 'viewer';

// `existingManagerRole` names a manager-equivalent role that predates the tiers. It keeps its
// own name and its existing module/route/lockdown configuration untouched, and only picks up the
// manager tier's action grants — so a module never ends up with two near-identical manager roles.
const MODULE_TIER_DEFINITIONS: {
  rolePrefix: string;
  module: string;
  routePrefix: string;
  existingManagerRole?: string;
}[] = [
  { rolePrefix: 'export', module: 'export', routePrefix: '/export' },
  { rolePrefix: 'master_data', module: 'master_data', routePrefix: '/master' },
  { rolePrefix: 'hr', module: 'hr', routePrefix: '/hr' },
  { rolePrefix: 'wip', module: 'wip_management', routePrefix: '/wip' },
  { rolePrefix: 'rejections', module: 'rejections_wastages', routePrefix: '/rejections' },
  { rolePrefix: 'quality_score', module: 'quality_score', routePrefix: '/quality-score' },
  { rolePrefix: 'performance', module: 'performance', routePrefix: '/performance' },
  { rolePrefix: 'floor_inventory', module: 'floor_inventory', routePrefix: '/floor-inventory' },
  { rolePrefix: 'fixed_assets', module: 'fixed_assets', routePrefix: '/fixed-assets' },
  { rolePrefix: 'five_s', module: 'five_s', routePrefix: '/five-s' },
  { rolePrefix: 'hourly_production', module: 'hourly_production', routePrefix: '/hourly-production' },
  { rolePrefix: 'rd', module: 'rd', routePrefix: '/rd' },
  { rolePrefix: 'crm', module: 'crm', routePrefix: '/crm' },
  { rolePrefix: 'marketing', module: 'marketing', routePrefix: '/marketing' },
  { rolePrefix: 'projects', module: 'projects', routePrefix: '/projects', existingManagerRole: 'project_manager' },
  { rolePrefix: 'qa', module: 'qa', routePrefix: '/qa', existingManagerRole: 'qa_manager' },
  { rolePrefix: 'maintenance', module: 'maintenance', routePrefix: '/maintenance', existingManagerRole: 'maintenance_manager' },
  { rolePrefix: 'expenses', module: 'expenses', routePrefix: '/expenses' },
  { rolePrefix: 'material_consumption', module: 'material_consumption', routePrefix: '/consumption' },
  { rolePrefix: 'machine_monitor', module: 'machine_monitor', routePrefix: '/machine-monitor' },
  { rolePrefix: 'production', module: 'production', routePrefix: '/production' },
  { rolePrefix: 'gate_pass', module: 'gate_pass', routePrefix: '/gate-pass' },
  { rolePrefix: 'store_pass', module: 'store_pass', routePrefix: '/store-pass' },
  { rolePrefix: 'dispatch_planner', module: 'dispatch_planner', routePrefix: '/dispatch-planner' },
  // Admin & Facilities: camera checks, cleaning inspections, asset custody, admin store, SIMs, equipment tickets.
  { rolePrefix: 'facilities', module: 'facilities', routePrefix: '/facilities' },
];

const MODULE_TIERS: ModuleTier[] = ['manager', 'officer', 'viewer'];

// The role that carries a given tier for a module — the pre-existing manager where one is
// declared, otherwise the generated `<prefix>_<tier>` name.
const tierRoleName = (
  def: (typeof MODULE_TIER_DEFINITIONS)[number],
  tier: ModuleTier,
): string =>
  tier === 'manager' && def.existingManagerRole
    ? def.existingManagerRole
    : `${def.rolePrefix}_${tier}`;

// role name → { module, tier }, used by hasModulePermission to grant the tier's actions.
const MODULE_TIER_ROLES: Record<string, { module: string; tier: ModuleTier }> = {};
for (const def of MODULE_TIER_DEFINITIONS) {
  for (const tier of MODULE_TIERS) {
    MODULE_TIER_ROLES[tierRoleName(def, tier)] = { module: def.module, tier };
  }
}

// Gate Pass approvers, one per pass type (sample / returnable / job work / scrap).
const GATE_PASS_TYPE_MANAGER_ROLES: string[] = [
  'gate_pass_sample_manager',
  'gate_pass_returnable_manager',
  'gate_pass_jobwork_manager',
  'gate_pass_scrap_manager',
];

// Define which modules each special role can access
const ROLE_MODULE_ACCESS: Record<string, string[]> = {
  operational_manager: ['production', 'qa', 'dashboard'],
  qa_manager: ['qa', 'dashboard'],
  // QA Super Manager: everything the QA Manager can do, plus setting the daily inspection
  // targets (Daily Quality Plan). Never deletes (see hasModulePermission).
  qa_super_manager: ['qa', 'dashboard'],
  maintenance_manager: ['maintenance', 'dashboard'],
  operator: ['qa', 'dashboard'], // Operators need QA access for inspections
  sales_executive: ['sales'], // Sales executives access sales module only
  order_management: ['production'], // Order management: production orders only
  floor_incharge: ['labour'], // Floor incharge: labour productivity entry only
  private_label_distributor: ['sales'], // Private label distributors: sales module (view-only) only
  // Private Label Sales access tiers (sales module, private-label pages only):
  //   • private_label_manager → view / create / edit / approve (no delete)
  //   • private_label_officer → view / create / edit
  //   • private_label_viewer  → view only
  private_label_manager: ['sales', 'dashboard'],
  private_label_officer: ['sales', 'dashboard'],
  private_label_viewer: ['sales', 'dashboard'],
  pettycash_handler: ['expenses'], // Petty cash handler: petty cash page only
  // Store operator: stock closing page, plus the Gate Inward Register (read-only: what is at the gate).
  store_operator: ['material_consumption', 'purchase'],
  project_manager: ['projects', 'dashboard'], // Project manager: project management module only
  // Projects Super Manager: sees every user's projects and their progress, can create
  // projects/tasks/documents, but can never delete anything (see hasModulePermission).
  projects_super_manager: ['projects', 'dashboard'],
  online_sales_packing: ['online_sales'], // Online sales packing: online orders page only (scan & weigh)
  // Online Sales access tiers — confined to the Online Sales module (+ dashboard shell).
  //   • online_sales_admin   — full module: every page incl. financials & masters, all actions.
  //   • online_sales_manager — full module visibility incl. financials; all actions except delete.
  //   • online_sales_agent   — operational fulfilment only (orders/customers/returns/live-status/
  //                            inventory) via ROLE_ROUTE_RESTRICTIONS; never sees money (canViewPrices).
  online_sales_admin: ['online_sales', 'dashboard'],
  online_sales_manager: ['online_sales', 'dashboard'],
  online_sales_agent: ['online_sales', 'dashboard'],
  // Dispatch operator: domestic dispatch page only. 'sales' keeps the Sales sidebar group
  // visible; 'domestic' satisfies the /domestic/* module check in ProtectedRoute. No pricing
  // page (Orders/Invoices) is reachable, so prices are never exposed.
  dispatch_operator: ['sales', 'domestic'],
  // Sales order manager: domestic sales order making + dispatch coordination + dashboards.
  // 'sales' keeps the Sales sidebar group visible; 'domestic' satisfies the /domestic/* module
  // check; 'dashboard' for the landing shell. Prices are hidden in-page (see canViewPrices).
  sales_order_manager: ['sales', 'domestic', 'dashboard'],
  // Production operator: full Production + Production Planning access. Can post/unpost
  // production entries (approve, granted in hasModulePermission below) and edit within a
  // 48h window (enforced in the entry/planning pages). No delete; planning has no approve.
  production_operator: ['production', 'planning', 'dashboard'],
  // Closing Data Poster: posts Daily Stock Closing (Production Planning) and Stock Closing
  // (Material Consumption), and makes Company Product Job Orders (Production Planning).
  // Module access opens both sidebar groups; route restrictions below confine it to those pages.
  closing_data_poster: ['planning', 'material_consumption', 'dashboard'],
  // Accounting access tiers — limited to the accounting module (+ dashboard landing)
  accounting_poster: ['accounting', 'dashboard'],
  // Accounting Officer: accounting (no P&L / Balance Sheet) + cross-module operational
  // access — Production (view-only, incl. WIP Ledger), full Sales/Purchase (make invoices,
  // returns, orders, dispatches, goods receipts) and Master Data (create products/items/etc).
  // Action limits in hasModulePermission.
  accounting_officer: ['accounting', 'dashboard', 'production', 'sales', 'domestic', 'export', 'purchase', 'master_data'],
  accounting_manager: ['accounting', 'dashboard'],
  // Purchase roles operate the Purchase module (+ dashboard shell). Officer creates
  // purchase orders/requests and receives goods; Manager additionally approves and
  // handles purchase invoices/returns. Confined to purchase routes via ROLE_ROUTE_RESTRICTIONS.
  // The Manager also reads the raw-material consumption reports (Material Consumption
  // module) to plan purchases; the route whitelist keeps the rest of that module hidden.
  purchase_officer: ['purchase', 'dashboard'],
  purchase_manager: ['purchase', 'dashboard', 'material_consumption'],
  // Purchase QC Inspector: a single-purpose quality role. 'purchase' keeps the
  // Purchase sidebar group visible and satisfies the /purchase/* module check;
  // route lockdown below confines it to just the Quality Inspection page, and it
  // never sees prices (canViewPrices).
  purchase_qc_inspector: ['purchase', 'dashboard'],
  // QA Inspector: a single-purpose quality role. 'qa' satisfies the /qa/* module
  // check; route lockdown below confines it to just the inspection entry form —
  // no QA dashboard or any other QA page.
  qa_inspector: ['qa'],
  // Gate Security: the gate guard. 'gate_pass' satisfies the /gate-pass/* module check;
  // route lockdown below confines it to the Gate Check page, and it never sees prices.
  gate_security: ['gate_pass'],
  // Gate Pass type managers: approve / reject one pass type (checked in the database).
  // They can open the whole Gate Pass module read-only, nothing else.
  gate_pass_sample_manager: ['gate_pass', 'dashboard'],
  gate_pass_returnable_manager: ['gate_pass', 'dashboard'],
  gate_pass_jobwork_manager: ['gate_pass', 'dashboard'],
  gate_pass_scrap_manager: ['gate_pass', 'dashboard'],
  // Distributor Order Management — a self-contained external module. All three
  // distributor roles are confined to the 'distributor' module (+ dashboard shell).
  // Per-distributor data isolation is enforced in-page by filtering on distributor_id.
  distributor_sales: ['distributor', 'dashboard'],
  distributor_manager: ['distributor', 'dashboard'],
  distributor_admin: ['distributor', 'dashboard'],
  labour_productivity_approver: ['labour', 'dashboard'],
  labour_productivity_poster: ['labour', 'dashboard'],
  labour_productivity_viewer: ['labour', 'dashboard'],
  // Labour Gate Pass Approver: approves worker gate passes (half day / short leave).
  // Confined to the worker gate pass pages of the Labour module.
  labour_gate_pass_approver: ['labour', 'dashboard'],
  // Labour Attendance Delete Approver: approves supervisors' requests to delete a
  // worker's attendance entry marked by mistake. Confined to that page.
  labour_attendance_delete_approver: ['labour', 'dashboard'],
  // Production Coordinator: gives the reasons for MPH losses once production is
  // posted. Confined to MPH Loss Reasons + MPH Analysis.
  production_coordinator: ['labour', 'dashboard'],
  // Admin & Facilities special roles: the technician works only the equipment tickets
  // assigned to them; the cleaning supervisor only closes their cleaning action items.
  facilities_technician: ['facilities', 'dashboard'],
  cleaning_supervisor: ['facilities', 'dashboard'],
  // Staff Gate Pass Approver: approves staff gate passes (half day / short leave).
  // Confined to the staff gate pass pages of the HR module.
  staff_gate_pass_approver: ['hr', 'dashboard'],
  // Help Desk Manager: a single-purpose role confined to the ticket admin board.
  // 'dashboard' is already always allowed; there's no separate 'helpdesk' module
  // check anywhere (ProtectedRoute doesn't map /helpdesk to a module), so route
  // lockdown below is what actually confines this role.
  helpdesk_manager: ['dashboard'],
};

// Define specific route restrictions for roles (only these exact routes are allowed)
const ROLE_ROUTE_RESTRICTIONS: Record<string, string[]> = {
  order_management: ['/production/orders'], // Can ONLY access production orders page
  floor_incharge: ['/labour/entry', '/labour/todays-target', '/labour/gate-pass', '/labour/attendance-delete-requests'], // Labour productivity entry, today's target, worker gate passes (apply), attendance delete requests (raise / follow own)
  private_label_distributor: ['/sales/dashboard', '/sales/orders', '/sales/awaiting-dispatch', '/sales/dispatch', '/sales/customers', '/sales/customer-logos', '/sales/visit-dashboard'], // Private Label Sales view-only (all pages)
  // Private Label Sales tiers: the module's operational pages (no master-config pages like
  // City/Area Master, Customer Categories or Fuel Vehicles/Prices, which stay super-admin-only).
  private_label_manager: ['/sales/dashboard', '/sales/orders', '/sales/awaiting-dispatch', '/sales/dispatch', '/sales/customers', '/sales/customer-logos', '/sales/customer-pricing', '/sales/visit-dashboard', '/sales/salesman-activity', '/sales/planner', '/sales/fuel/trips', '/sales/fuel/payouts'],
  private_label_officer: ['/sales/dashboard', '/sales/orders', '/sales/awaiting-dispatch', '/sales/dispatch', '/sales/customers', '/sales/customer-logos', '/sales/customer-pricing', '/sales/visit-dashboard', '/sales/salesman-activity', '/sales/planner', '/sales/fuel/trips', '/sales/fuel/payouts'],
  private_label_viewer: ['/sales/dashboard', '/sales/orders', '/sales/awaiting-dispatch', '/sales/dispatch', '/sales/customers', '/sales/customer-logos', '/sales/customer-pricing', '/sales/visit-dashboard', '/sales/salesman-activity', '/sales/planner', '/sales/fuel/trips', '/sales/fuel/payouts'],
  pettycash_handler: ['/expenses/petty-cash', '/expenses/trip-fuel', '/expenses/freight-vouchers'], // Petty cash handler: petty cash, trip fuel vouchers and freight vouchers they pay
  store_operator: ['/consumption/stock-closing', '/consumption/reorder-requirement', '/purchase/gate-inward', '/purchase/material-shortages'], // Store operator: stock closing + reorder requirement + gate inward register + raw-material shortage alerts
  project_manager: ['/projects', '/projects/list', '/projects/kanban'], // Project manager: project management pages only
  projects_super_manager: ['/projects', '/dashboard'], // Projects Super Manager: whole Project Management module
  online_sales_packing: ['/online-sales/orders'], // Online sales packing: orders page only (scan & weigh)
  // Online Sales Admin & Manager: the whole module. The '/online-sales' prefix matches every
  // page under it; the Admin/Manager distinction is purely in action permissions (Manager
  // cannot delete — see hasModulePermission), not in which pages they can open.
  online_sales_admin: ['/online-sales'],
  online_sales_manager: ['/online-sales'],
  // Online Sales Agent: front-line fulfilment only — make/edit orders, manage customers,
  // process returns, watch live status and check stock. NO financial, analytics, settlement
  // or master-config pages (P&L, Money/COD, Payment Receipts, Marketing, Agencies, Agency
  // Settlement, Expenses, Sales Analysis, Returns Analytics, Reconciliation, Platform/Item Master).
  online_sales_agent: [
    '/online-sales/orders',
    '/online-sales/customers',
    '/online-sales/returns',
    '/online-sales/live-status',
    '/online-sales/inventory',
  ],
  dispatch_operator: ['/domestic/dispatch'], // Dispatch operator: domestic dispatch page only (no pricing pages)
  // Sales order manager: order making + dispatch coordination + dashboards (NO products, invoices, or pricing pages)
  sales_order_manager: [
    '/domestic/orders',
    '/domestic/order-status',
    '/domestic/customers',
    '/domestic/pending-dispatch',
    '/domestic/dispatch',
    '/domestic/dispatch-dashboard',
    '/domestic/dispatch-acknowledgement',
    '/domestic/dashboard',
  ],
  // Production operator: full Production + Planning modules (prefix match covers all their pages).
  production_operator: ['/production', '/planning', '/dashboard'],
  // Closing Data Poster: ONLY the two stock-closing pages — Daily Stock Closing (Planning)
  // and Stock Closing (Material Consumption) — plus Reorder Requirement and Company Product
  // Job Orders (Planning). Nothing else in those modules is reachable.
  closing_data_poster: [
    '/planning/stock-closing',
    '/planning/company-job-orders',
    '/consumption/stock-closing',
    '/consumption/reorder-requirement',
  ],
  // Accounting Poster: post entries + review books/ledgers + read masters needed to post.
  // NO reports and NO accounting dashboard (it surfaces cash/bank/inventory balances).
  accounting_poster: [
    '/accounting/vouchers/new',
    '/accounting/vouchers',
    '/accounting/customer-receipts',
    '/accounting/supplier-payments',
    '/accounting/sales-return',
    '/accounting/purchase-return',
    '/accounting/day-book',
    '/accounting/cash-book',
    '/accounting/bank-book',
    '/accounting/general-ledger',
    '/accounting/party-ledger',
    '/accounting/parties',
    '/accounting/freight-vouchers',
  ],
  // Purchase Officer: create purchase orders & requests, receive goods, view suppliers.
  // No approvals (separation of duties) and no purchase invoices/returns.
  purchase_officer: [
    '/purchase/dashboard',
    '/purchase/suppliers',
    '/purchase/requests',
    '/purchase/orders',
    '/purchase/grn',
    '/purchase/gate-inward',
    '/purchase/material-shortages',
  ],
  // Purchase Manager: full purchase operations incl. approvals, invoices, returns
  // and the Purchase Analysis report (spend, supplier concentration, fulfilment),
  // plus the raw-material consumption reports (Material Consumption module) that
  // drive purchase planning: Key Raw Materials, Usage Report, Value Tier Usage
  // Report and Reorder Requirement. No other Material Consumption page.
  purchase_manager: [
    '/purchase/dashboard',
    '/purchase/analysis',
    '/purchase/suppliers',
    '/purchase/requests',
    '/purchase/orders',
    '/purchase/grn',
    '/purchase/gate-inward',
    '/purchase/qc-parameters',
    '/purchase/invoices',
    '/purchase/returns',
    '/purchase/material-shortages',
    '/consumption/key-raw-materials',
    '/consumption/usage-report',
    '/consumption/value-tier-report',
    '/consumption/reorder-requirement',
  ],
  // Purchase QC Inspector: ONLY the Quality Inspection page. No orders, goods
  // receipt, invoices, returns, suppliers or dashboard (all of which expose
  // prices/amounts).
  purchase_qc_inspector: [
    '/purchase/qc',
  ],
  // QA Inspector: ONLY the inspection entry form (chrome-free operator layout).
  // No QA dashboard, inspections list, release, NCR/CAPA or master pages.
  qa_inspector: [
    '/qa/operator-inspection',
  ],
  // Gate Security: the Gate Check page (scan, count each line, mark Out or hold) and
  // the inward entries it records (/gate-pass/inward/new, /gate-pass/inward/:id).
  gate_security: [
    '/gate-pass/check',
    '/gate-pass/inward',
  ],
  gate_pass_sample_manager: ['/gate-pass', '/dashboard'],
  gate_pass_returnable_manager: ['/gate-pass', '/dashboard'],
  gate_pass_jobwork_manager: ['/gate-pass', '/dashboard'],
  gate_pass_scrap_manager: ['/gate-pass', '/dashboard'],
  // Distributor Sales: ONLY make/submit sales orders. The orders page is fully
  // self-contained — customers and products load inside the order dialog — so no
  // customers, products, analysis, approvals, dispatch, dashboard or user pages.
  distributor_sales: [
    '/distributor/orders',
  ],
  // Distributor Manager: everything sales can do, plus approve/reject/edit orders
  // and run the dispatch sheet. No user management.
  distributor_manager: [
    '/distributor/dashboard',
    '/distributor/customers',
    '/distributor/products',
    '/distributor/orders',
    '/distributor/analysis',
    '/distributor/approvals',
    '/distributor/dispatch',
  ],
  // Distributor Admin: full distributor module + manage their own sales/manager users.
  distributor_admin: [
    '/distributor/dashboard',
    '/distributor/customers',
    '/distributor/products',
    '/distributor/orders',
    '/distributor/analysis',
    '/distributor/approvals',
    '/distributor/dispatch',
    '/distributor/admin',
  ],
  // Labour Productivity Approver: full labour module access except admin pages
  labour_productivity_approver: ['/labour', '/labour/dashboard', '/labour/edit-requests', '/labour/attendance-delete-requests', '/labour/entry', '/labour/todays-target', '/labour/employees', '/labour/attendance', '/labour/salary', '/labour/timesheet', '/labour/categories', '/labour/process-targets', '/labour/deployment-analysis', '/labour/category-productivity', '/labour/process-productivity', '/labour/individual-performance', '/labour/missing-entries', '/labour/mph-analysis', '/labour/mph-calculation-report', '/labour/mph-loss-reasons', '/labour/mph-loss-analysis'],
  // Labour Productivity Poster: create and post entries only (no dashboard access)
  labour_productivity_poster: ['/labour/entry', '/labour/todays-target', '/labour/gate-pass', '/labour/attendance-delete-requests'],
  // Labour Productivity Viewer: read-only access
  labour_productivity_viewer: ['/labour/dashboard', '/labour/gate-pass'],
  // Labour Gate Pass Approver: the worker gate pass register, approvals and pass pages only.
  labour_gate_pass_approver: ['/labour/gate-pass', '/dashboard'],
  // Labour Attendance Delete Approver: the attendance delete requests page (approvals + log sheet) only.
  labour_attendance_delete_approver: ['/labour/attendance-delete-requests', '/dashboard'],
  // Production Coordinator: MPH loss reasons (entry + print), their analysis, MPH Analysis and the MPH Calculation Report only.
  production_coordinator: ['/labour/mph-loss-reasons', '/labour/mph-loss-analysis', '/labour/mph-analysis', '/labour/mph-calculation-report', '/dashboard'],
  facilities_technician: ['/facilities/equipment/tickets', '/dashboard'],
  cleaning_supervisor: ['/facilities/cleaning/actions', '/dashboard'],
  // Staff Gate Pass Approver: the staff gate pass register, approvals and pass pages only.
  staff_gate_pass_approver: ['/hr/gate-pass', '/dashboard'],
  // Help Desk Manager: manages all tickets (view/assign/comment/resolve) on the
  // admin ticket board. The submit page ('/helpdesk') is already open to every
  // role via the explicit bypass in canAccessRoute below.
  helpdesk_manager: ['/helpdesk', '/dashboard'],
};

// Routes a role is explicitly DENIED even though it otherwise has broad access to the module.
// (Used for "see everything except these statements" tiers.)
const ROLE_ROUTE_DENY: Record<string, string[]> = {
  // Accounting Officer: no financial statements, and no access to the super-admin-only
  // production master/config tools (which have no in-page permission gating). Everything
  // else in Production stays view-only via hasModulePermission.
  accounting_officer: [
    '/accounting/profit-loss',
    '/accounting/balance-sheet',
    '/accounting/equity-changes',
    '/production/mph-master',
    '/production/wip-sequence',
  ],
  // Labour Productivity Approver: no access to admin/config pages
  labour_productivity_approver: [
    '/labour/public-holidays',
    '/labour/mph-management',
  ],
  // Production tiers: the super-admin-only production master/config tools carry no
  // in-page permission gating (same denial as accounting_officer above). Grade Ledger
  // Setup is already guarded by requiredRole="super_admin" on its route.
  production_manager: ['/production/mph-master', '/production/wip-sequence'],
  production_officer: ['/production/mph-master', '/production/wip-sequence'],
  production_viewer: ['/production/mph-master', '/production/wip-sequence'],
};

// The route prefix that hosts each module's pages. Used to derive an implicit route
// whitelist for hard-restricted roles that carry no explicit ROLE_ROUTE_RESTRICTIONS
// entry (accounting_manager, accounting_officer, qa_manager, …): when a strict-locked
// role on the same account forces whitelist-union mode in canAccessRoute, those roles
// must still contribute their own module scope — otherwise adding e.g. an HR or Labour
// Productivity tier to an accounting account silently hides every accounting page.
const MODULE_ROUTE_PREFIXES: Record<string, string> = {
  dashboard: '/dashboard',
  accounting: '/accounting',
  production: '/production',
  planning: '/planning',
  sales: '/sales',
  domestic: '/domestic',
  export: '/export',
  purchase: '/purchase',
  qa: '/qa',
  maintenance: '/maintenance',
  labour: '/labour',
  expenses: '/expenses',
  material_consumption: '/consumption',
  projects: '/projects',
  online_sales: '/online-sales',
  distributor: '/distributor',
  master_data: '/master',
};
for (const def of MODULE_TIER_DEFINITIONS) {
  MODULE_ROUTE_PREFIXES[def.module] ??= def.routePrefix;
}

const implicitRouteWhitelist = (role: string): string[] =>
  (ROLE_MODULE_ACCESS[role] ?? [])
    .map((m) => MODULE_ROUTE_PREFIXES[m])
    .filter((p): p is string => Boolean(p));

const HARD_RESTRICTED_MODULE_ROLES = new Set([
  'qa_manager',
  'qa_super_manager',
  'maintenance_manager',
  'operator',
  'sales_executive',
  'order_management',
  'floor_incharge',
  'private_label_distributor',
  'private_label_manager',
  'private_label_officer',
  'private_label_viewer',
  'pettycash_handler',
  'store_operator',
  'project_manager',
  'projects_super_manager',
  'online_sales_packing',
  'online_sales_admin',
  'online_sales_manager',
  'online_sales_agent',
  'accounting_poster',
  'accounting_officer',
  'accounting_manager',
  'purchase_officer',
  'purchase_manager',
  'purchase_qc_inspector',
  'qa_inspector',
  'gate_security',
  'gate_pass_sample_manager',
  'gate_pass_returnable_manager',
  'gate_pass_jobwork_manager',
  'gate_pass_scrap_manager',
  'dispatch_operator',
  'sales_order_manager',
  'production_operator',
  'closing_data_poster',
  'distributor_sales',
  'distributor_manager',
  'distributor_admin',
  'labour_productivity_approver',
  'labour_productivity_poster',
  'labour_productivity_viewer',
  'labour_gate_pass_approver',
  'labour_attendance_delete_approver',
  'production_coordinator',
  'staff_gate_pass_approver',
  'helpdesk_manager',
  'facilities_technician',
  'cleaning_supervisor',
]);

// Strict single-purpose roles whose lockdown must ALWAYS be enforced, even when the user
// also holds a "flexible" role (admin/manager/viewer/etc.). This prevents a stray flexible
// role from silently bypassing the module/route restrictions (and price hiding) of these
// security-sensitive roles. Super admin still overrides everything.
const STRICT_LOCKED_ROLES = new Set([
  'dispatch_operator',
  'sales_order_manager',
  'production_operator',
  'closing_data_poster',
  // Purchase QC Inspector must never gain price visibility or reach other purchase
  // pages, even if the user also holds a flexible role — enforce its lockdown always.
  'purchase_qc_inspector',
  // QA Inspector must never reach any QA page beyond the inspection entry form,
  // even if the user also holds a flexible role — enforce its lockdown always.
  'qa_inspector',
  // Gate Security must never reach any page beyond Gate Check, nor see prices.
  'gate_security',
  'gate_pass_sample_manager',
  'gate_pass_returnable_manager',
  'gate_pass_jobwork_manager',
  'gate_pass_scrap_manager',
  'distributor_sales',
  'distributor_manager',
  'distributor_admin',
  // Online Sales tiers are security-sensitive (the Agent must never see money), so their
  // module/route lockdown is enforced even if the user also holds a flexible role.
  'online_sales_admin',
  'online_sales_manager',
  'online_sales_agent',
  // Labour Productivity tiers are role-specific (approver/poster/viewer), enforce lockdown.
  'labour_productivity_approver',
  'labour_productivity_poster',
  'labour_productivity_viewer',
  // Labour Gate Pass Approver only ever sees the worker gate pass pages.
  'labour_gate_pass_approver',
  // Labour Attendance Delete Approver only ever sees the attendance delete requests page.
  'labour_attendance_delete_approver',
  // Production Coordinator only ever sees the MPH loss reason pages and MPH Analysis.
  'production_coordinator',
  // Staff Gate Pass Approver only ever sees the staff gate pass pages.
  'staff_gate_pass_approver',
  // Private Label Sales tiers share the 'sales' module with unrelated roles (sales_executive,
  // dispatch_operator, sales_order_manager, accounting_officer, ...) — enforce their explicit
  // route whitelist always so a stray flexible role never widens them past private-label pages.
  'private_label_manager',
  'private_label_officer',
  'private_label_viewer',
  // Help Desk Manager is a single-purpose ticket-admin role — enforce its
  // lockdown always, even if the user also holds a flexible role.
  'helpdesk_manager',
  // Projects Super Manager is confined to the Project Management module.
  'projects_super_manager',
]);

// Register every module tier into the four maps/sets above. Doing it in one loop keeps
// the 39 roles consistent: each gets its own module (+ dashboard shell), a route whitelist
// covering its module prefix, and hard/strict lockdown so a stray flexible role cannot
// silently widen the scope (same treatment as the Labour Productivity tiers).
for (const def of MODULE_TIER_DEFINITIONS) {
  for (const tier of MODULE_TIERS) {
    const role = tierRoleName(def, tier);
    // A pre-existing manager role (project_manager / qa_manager / maintenance_manager) already
    // has its own module scope and lockdown settled; re-registering it here would silently
    // change how existing accounts behave. It takes the action grants only.
    if (role === def.existingManagerRole) continue;
    ROLE_MODULE_ACCESS[role] = [def.module, 'dashboard'];
    ROLE_ROUTE_RESTRICTIONS[role] = [def.routePrefix, '/dashboard'];
    HARD_RESTRICTED_MODULE_ROLES.add(role);
    STRICT_LOCKED_ROLES.add(role);
  }
}
// Gate pass managers also read the Store Pass module (dispatch tracking and the
// store ↔ gate reconciliation): the gate is the other half of that comparison.
ROLE_MODULE_ACCESS['gate_pass_manager'].push('store_pass');
ROLE_ROUTE_RESTRICTIONS['gate_pass_manager'].push('/store-pass');
// The Dispatch Planner only READS sales orders, dispatches and stock and suggests a plan;
// the people who make the orders and the dispatches read its pages (view only — the
// planner's own writes stay with the dispatch_planner_* tiers).
for (const r of ['sales_order_manager', 'dispatch_operator'] as const) {
  ROLE_MODULE_ACCESS[r].push('dispatch_planner');
  ROLE_ROUTE_RESTRICTIONS[r].push('/dispatch-planner');
}
// Purchase Request roles (an Officer and an Approver per purchase category). Confined to
// Purchase → Purchase Requests (+ dashboard shell); My Purchase Requests is open to every
// role anyway. Which categories they see and approve: hasPurchaseCategoryPermission and
// lib/purchase/categories.ts. The approval itself is checked in the database.
const PURCHASE_REQUEST_ROLE_NAMES = [
  'pr_office_officer', 'pr_office_approver',
  'pr_raw_material_officer', 'pr_raw_material_approver',
  'pr_production_officer', 'pr_production_approver',
  'pr_spares_officer', 'pr_spares_approver',
];
const PURCHASE_REQUEST_ROLE_CATEGORY: Record<string, { category: PurchaseCategoryPermission['category']; approver: boolean }> = {
  pr_office_officer: { category: 'office_supplies', approver: false },
  pr_office_approver: { category: 'office_supplies', approver: true },
  pr_raw_material_officer: { category: 'raw_material', approver: false },
  pr_raw_material_approver: { category: 'raw_material', approver: true },
  pr_production_officer: { category: 'general_supplies', approver: false },
  pr_production_approver: { category: 'general_supplies', approver: true },
  pr_spares_officer: { category: 'spare_maintenance', approver: false },
  pr_spares_approver: { category: 'spare_maintenance', approver: true },
};
for (const r of PURCHASE_REQUEST_ROLE_NAMES) {
  ROLE_MODULE_ACCESS[r] = ['purchase', 'dashboard'];
  ROLE_ROUTE_RESTRICTIONS[r] = ['/purchase/requests', '/dashboard'];
  HARD_RESTRICTED_MODULE_ROLES.add(r);
  STRICT_LOCKED_ROLES.add(r);
}

interface ModulePermission {
  module_name: string;
  can_view: boolean;
  can_create: boolean;
  can_edit: boolean;
  can_delete: boolean;
  can_approve: boolean;
}

interface PurchaseCategoryPermission {
  category: 'raw_material' | 'office_supplies' | 'general_supplies' | 'spare_maintenance';
  can_view: boolean;
  can_create: boolean;
  can_approve: boolean;
}

interface AuthContextType {
  user: AppUser | null;
  roles: UserRole[];
  modulePermissions: ModulePermission[];
  purchaseCategoryPermissions: PurchaseCategoryPermission[];
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (userId: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  // Re-reads the signed-in user's app_users row (after a profile / photo edit).
  refreshUser: () => Promise<void>;
  hasRole: (role: UserRole['role']) => boolean;
  hasModulePermission: (module: string, permission: 'view' | 'create' | 'edit' | 'delete' | 'approve') => boolean;
  hasPurchaseCategoryPermission: (category: PurchaseCategoryPermission['category'], permission: 'view' | 'create' | 'approve') => boolean;
  canAccessModule: (module: string) => boolean;
  canAccessRoute: (route: string) => boolean;
  canViewPrices: () => boolean;
  // Distributor scope: company staff (super_admin) see all distributors; a distributor
  // user is confined to their own distributor_id. Pages use this to filter every query.
  getDistributorScope: () => { isCompany: boolean; distributorId: string | null };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SESSION_KEY = 'erp_session';
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const isValidUuid = (value: unknown): value is string =>
  typeof value === 'string' && UUID_REGEX.test(value);

const sanitizeStoredSession = () => {
  if (typeof window === 'undefined') return;

  try {
    const rawSession = window.localStorage.getItem(SESSION_KEY);
    if (!rawSession) return;

    const parsed = JSON.parse(rawSession);
    const userUuid = parsed?.userUuid;
    const expiry = parsed?.expiry;

    if (!isValidUuid(userUuid) || typeof expiry !== 'number' || Date.now() >= expiry) {
      window.localStorage.removeItem(SESSION_KEY);
    }
  } catch {
    window.localStorage.removeItem(SESSION_KEY);
  }
};

sanitizeStoredSession();

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [modulePermissions, setModulePermissions] = useState<ModulePermission[]>([]);
  const [purchaseCategoryPermissions, setPurchaseCategoryPermissions] = useState<PurchaseCategoryPermission[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadUserData = useCallback(async (userUuid: string) => {
    if (!isValidUuid(userUuid)) {
      localStorage.removeItem(SESSION_KEY);
      setUser(null);
      setRoles([]);
      setModulePermissions([]);
      setPurchaseCategoryPermissions([]);
      return false;
    }

    try {
      const { data: userData, error: userError } = await supabase
        .from('app_users')
        .select('*')
        .eq('id', userUuid)
        .single();

      if (userError || !userData) {
        console.error('Error loading user data:', userError);
        return false;
      }

      setUser(userData);

      const { data: rolesData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userUuid);

      setRoles((rolesData || []) as UserRole[]);

      const { data: modulePermsData } = await supabase
        .from('module_permissions')
        .select('module_name, can_view, can_create, can_edit, can_delete, can_approve')
        .eq('user_id', userUuid);

      setModulePermissions((modulePermsData || []) as ModulePermission[]);

      const { data: purchasePermsData } = await supabase
        .from('purchase_category_permissions')
        .select('category, can_view, can_create, can_approve')
        .eq('user_id', userUuid);

      setPurchaseCategoryPermissions((purchasePermsData || []) as PurchaseCategoryPermission[]);

      return true;
    } catch (error) {
      console.error('Error loading user data:', error);
      return false;
    }
  }, []);

  useEffect(() => {
    // Demo-only bypass: skip Supabase auth, inject a stub super_admin user
    if (import.meta.env.VITE_DEMO_BYPASS === 'true') {
      setUser({
        id: '00000000-0000-0000-0000-000000000000',
        user_id: 'demo',
        full_name: 'Demo User',
        department_id: null,
        designation: 'Demo',
        is_active: true,
        last_login: new Date().toISOString(),
        distributor_id: null,
      });
      setRoles([{ role: 'super_admin' }]);
      setModulePermissions([]);
      setPurchaseCategoryPermissions([]);
      setIsLoading(false);
      return;
    }

    const checkSession = async () => {
      sanitizeStoredSession();
      const sessionData = localStorage.getItem(SESSION_KEY);

      if (sessionData) {
        try {
          const { userUuid, expiry } = JSON.parse(sessionData);

          if (!isValidUuid(userUuid) || typeof expiry !== 'number' || Date.now() >= expiry) {
            localStorage.removeItem(SESSION_KEY);
          } else {
            const success = await loadUserData(userUuid);
            if (!success) {
              localStorage.removeItem(SESSION_KEY);
            }
          }
        } catch {
          localStorage.removeItem(SESSION_KEY);
        }
      }

      setIsLoading(false);
    };

    checkSession();
  }, [loadUserData]);

  const login = async (userId: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.rpc('verify_user_password', {
        p_user_id: userId,
        p_password: password
      });

      if (error) {
        console.error('Login error:', error);
        return { success: false, error: 'Authentication failed. Please try again.' };
      }

      if (!data || data.length === 0 || !data[0].is_valid) {
        return { success: false, error: 'Invalid user ID or password.' };
      }

      const userUuid = data[0].user_uuid;
      if (!isValidUuid(userUuid)) {
        localStorage.removeItem(SESSION_KEY);
        return { success: false, error: 'Invalid session data returned. Please try again.' };
      }

      const success = await loadUserData(userUuid);

      if (!success) {
        return { success: false, error: 'Failed to load user data.' };
      }

      const sessionData = {
        userUuid,
        expiry: Date.now() + (24 * 60 * 60 * 1000)
      };
      localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));

      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'An unexpected error occurred.' };
    }
  };

  const refreshUser = useCallback(async () => {
    if (!user?.id) return;
    const { data } = await supabase.from('app_users').select('*').eq('id', user.id).single();
    if (data) setUser(data as AppUser);
  }, [user?.id]);

  const logout = () => {
    // Login/failed-login events are recorded inside verify_user_password;
    // logout only happens client-side so it is recorded here.
    logActivity({ module: 'auth', action: 'logout' });
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
    setRoles([]);
    setModulePermissions([]);
    setPurchaseCategoryPermissions([]);
  };

  const hasRole = (role: UserRole['role']): boolean => {
    return roles.some(r => r.role === role) || roles.some(r => r.role === 'super_admin');
  };

  // Whether the current user may see monetary values (prices, rates, amounts, totals).
  // Roles that manage logistics/orders without commercial visibility are hidden from money.
  const canViewPrices = (): boolean => {
    if (roles.some(r => r.role === 'super_admin')) return true;
    // sales_order_manager (domestic logistics), online_sales_agent (online fulfilment) and
    // purchase_qc_inspector (quality control) operate without any commercial visibility —
    // hide every monetary value from them.
    return !roles.some(r =>
      r.role === 'sales_order_manager' ||
      r.role === 'online_sales_agent' ||
      r.role === 'purchase_qc_inspector' ||
      r.role === 'gate_security'
    );
  };

  // Distributor data-isolation scope. super_admin is the company actor that can see
  // every distributor's data; any distributor user is locked to their own distributor_id.
  const getDistributorScope = (): { isCompany: boolean; distributorId: string | null } => {
    const isCompany = roles.some(r => r.role === 'super_admin');
    return { isCompany, distributorId: user?.distributor_id ?? null };
  };

  // Check if user can access a specific module (module permissions are the source of truth)
  const canAccessModule = (module: string): boolean => {
    const normalizeModule = (m: string) => {
      const key = m.toLowerCase();
      // Support legacy keys / inconsistent callers
      if (key === 'master') return 'master_data';
      return key;
    };

    const mod = normalizeModule(module);

    // Super admin has all access
    if (roles.some((r) => r.role === 'super_admin')) return true;

    // Always allow the main dashboard shell so users have somewhere to land
    if (mod === 'dashboard') return true;

    // Strict-locked roles enforce their own module scope regardless of any FLEXIBLE role the
    // user may also hold (closes the "stray Viewer/Manager bypasses the lockdown" gap). When the
    // user also holds another *scoped* role (e.g. pettycash_handler alongside dispatch_operator),
    // grant the union of all their hard-restricted module scopes — a flexible role still cannot
    // widen this, which is the whole point of "strict".
    // Per-user module permission rows are an explicit admin grant (not a stray role), so they
    // still apply — but ONLY for modules OUTSIDE every strict role's own scope. Inside a strict
    // role's scope the role stays the only authority, so permission rows can never widen e.g.
    // a purchase_qc_inspector's Purchase access or a labour viewer's Labour access.
    const strictRoles = roles.filter((r) => STRICT_LOCKED_ROLES.has(r.role));
    if (strictRoles.length > 0) {
      const scopedRoles = roles.filter((r) => HARD_RESTRICTED_MODULE_ROLES.has(r.role));
      if (scopedRoles.some((r) => ROLE_MODULE_ACCESS[r.role]?.includes(mod))) return true;
      const strictScope = new Set(strictRoles.flatMap((r) => ROLE_MODULE_ACCESS[r.role] ?? []));
      if (!strictScope.has(mod)) {
        return !!modulePermissions.find((p) => p.module_name === mod)?.can_view;
      }
      return false;
    }

    // Accounting Officer: its module grants are role-driven and additive — they apply even
    // when the account also holds a flexible role (which would otherwise route to per-user
    // module permissions below and silently hide these modules).
    if (
      roles.some((r) => r.role === 'accounting_officer') &&
      ROLE_MODULE_ACCESS['accounting_officer']?.includes(mod)
    ) {
      return true;
    }

    // Purchase officer / manager: the purchase-module grant is role-driven and additive,
    // so it applies even when the account also holds a flexible role (which would otherwise
    // route to per-user module permissions below and hide the Purchase module).
    // Checked per role (not just the officer's list) so the manager's extra modules
    // (e.g. material_consumption reports) are granted too.
    if (
      roles.some(
        (r) =>
          (r.role === 'purchase_officer' || r.role === 'purchase_manager') &&
          ROLE_MODULE_ACCESS[r.role]?.includes(mod)
      )
    ) {
      return true;
    }

    const hardRestrictedRoles = roles.filter((r) => HARD_RESTRICTED_MODULE_ROLES.has(r.role));
    const hasFlexibleRole = roles.some((r) => !HARD_RESTRICTED_MODULE_ROLES.has(r.role));

    // If the user only has hard-restricted roles, allow the union of those role modules.
    // If they also have a flexible role, fall back to assigned module permissions instead.
    if (hardRestrictedRoles.length > 0 && !hasFlexibleRole) {
      return hardRestrictedRoles.some((r) => ROLE_MODULE_ACCESS[r.role]?.includes(mod));
    }

    // operational_manager: driven by module permissions
    if (roles.some((r) => r.role === 'operational_manager')) {
      const perm = modulePermissions.find((p) => p.module_name === mod);
      return !!perm?.can_view;
    }

    // All other roles: require module permission to view the module
    const perm = modulePermissions.find((p) => p.module_name === mod);
    return !!perm?.can_view;
  };

  const hasModulePermission = (module: string, permission: 'view' | 'create' | 'edit' | 'delete' | 'approve'): boolean => {
    // Super admin has all permissions
    if (roles.some(r => r.role === 'super_admin')) return true;

    // Purchase manager owns the full Purchase scope (view / create / edit / approve;
    // delete stays with super admin). Granted up-front so a more-restrictive role the
    // same user also holds — e.g. accounting_officer, which grants Purchase only
    // view/create/edit via an early return below — cannot veto the manager's approval
    // rights. (See the "earlier role vetoes a later one" note further down.)
    if (module === 'purchase' && roles.some(r => r.role === 'purchase_manager')) {
      return permission !== 'delete';
    }

    // Accounting access tiers (accounting module only; action perms implied by the role)
    if (module === 'accounting') {
      if (roles.some(r => r.role === 'accounting_manager')) return true; // full incl. delete + approve
      if (roles.some(r => r.role === 'accounting_poster' || r.role === 'accounting_officer')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
    }

    // Accounting Officer — cross-module operational access (additive to the accounting tier):
    //  • Production: view only (full read access including the WIP Ledger)
    //  • Sales / Domestic & Purchase: view + create + edit (make sales invoices & returns,
    //    purchase invoices via Goods Receipt & purchase returns, plus orders/dispatches).
    //  • Master Data: view + create + edit (create new products/items/grades/units, etc).
    //  Delete and approve stay with managers (separation of duties).
    if (roles.some(r => r.role === 'accounting_officer')) {
      if (module === 'production') return permission === 'view';
      if (
        module === 'sales' || module === 'domestic' || module === 'export' ||
        module === 'purchase' || module === 'master_data'
      ) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
    }

    // Floor incharge cannot approve labour data (hard restriction). Scoped to the
    // 'labour' module — floor_incharge's own access never extends beyond it (see
    // ROLE_MODULE_ACCESS above) — so it doesn't veto an unrelated approve grant from
    // another role the same user also holds (e.g. floor_incharge + production_operator
    // blocking that user's production 'Post Day' permission).
    if (roles.some(r => r.role === 'floor_incharge') && module === 'labour' && permission === 'approve') {
      return false;
    }

    // Labour Productivity access tiers (labour module only)
    //   • labour_productivity_approver → view / create / edit / approve (no delete)
    //   • labour_productivity_poster → view / create / edit (no delete/approve)
    //   • labour_productivity_viewer → view only
    if (module === 'labour') {
      if (roles.some(r => r.role === 'labour_productivity_approver')) {
        return permission !== 'delete';
      }
      if (roles.some(r => r.role === 'labour_productivity_poster')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
      if (roles.some(r => r.role === 'labour_productivity_viewer')) {
        return permission === 'view';
      }
      // Labour Gate Pass Approver: view only here; approving worker passes is
      // checked by role on the gate pass pages and in the database.
      if (roles.some(r => r.role === 'labour_gate_pass_approver')) {
        return permission === 'view';
      }
      // Labour Attendance Delete Approver: view only here; approving delete
      // requests is checked by role on the requests page and in the database.
      if (roles.some(r => r.role === 'labour_attendance_delete_approver')) {
        return permission === 'view';
      }
      // Production Coordinator: view only here; entering MPH loss reasons is
      // checked by role on the page and in the database.
      if (roles.some(r => r.role === 'production_coordinator')) {
        return permission === 'view';
      }
    }

    // Purchase officer cannot approve purchase orders — approval is reserved for
    // purchase_manager (separation of duties), unless the user also holds that role.
    if (
      permission === 'approve' &&
      module === 'purchase' &&
      roles.some(r => r.role === 'purchase_officer') &&
      !roles.some(r => r.role === 'purchase_manager')
    ) {
      return false;
    }

    // Purchase officer / manager operate the Purchase module.
    //   • purchase_manager → view / create / edit / approve (delete reserved for super admin)
    //   • purchase_officer → view / create / edit (approve already denied above)
    if (module === 'purchase') {
      if (roles.some(r => r.role === 'purchase_manager')) return permission !== 'delete';
      if (roles.some(r => r.role === 'purchase_officer')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
    }

    // Private label distributor: view-only access (no create, edit, delete, approve)
    if (roles.some(r => r.role === 'private_label_distributor')) {
      if (permission !== 'view') return false;
      // Allow view only for sales module
      return module === 'sales';
    }

    // Private Label Sales access tiers (sales module, private-label pages only):
    //   • private_label_manager → view / create / edit / approve (no delete)
    //   • private_label_officer → view / create / edit
    //   • private_label_viewer  → view only
    if (module === 'sales') {
      if (roles.some(r => r.role === 'private_label_manager')) return permission !== 'delete';
      if (roles.some(r => r.role === 'private_label_officer')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
      if (roles.some(r => r.role === 'private_label_viewer')) return permission === 'view';
    }

    // Pettycash handler: view and create only for the expenses module. GRANT-ONLY (additive)
    // so it never vetoes another scoped role the same user also holds — e.g. a user who is
    // also dispatch_operator must still get domestic create. Out-of-scope falls through.
    if (
      roles.some(r => r.role === 'pettycash_handler') &&
      module === 'expenses' &&
      (permission === 'view' || permission === 'create')
    ) {
      return true;
    }

    // production_operator can post/unpost the day's production entries (the "Post Day"
    // button and per-row Post/Unpost actions gate on the 'approve' permission). Delete
    // still stays reserved for super admin, and this grant is scoped to the production
    // module only — planning still falls through to grantsWithinScope below, which denies
    // approve there.
    if (roles.some(r => r.role === 'production_operator') && module === 'production' && permission === 'approve') {
      return true;
    }

    // Strict operational roles grant view/create/edit within their own module scope
    // (never delete/approve). These checks are GRANT-ONLY (additive): when the role is
    // out of scope they DO NOT return — they fall through so another strict role the same
    // user also holds can still grant its own modules. A hard `return module === X` here
    // used to let an earlier role veto a later one (e.g. a user holding both
    // sales_order_manager + production_operator had production create blocked because the
    // sales_order_manager branch returned false for the production module first).
    //   • dispatch_operator     → sales / domestic (dispatch; no pricing pages)
    //   • sales_order_manager   → sales / domestic (orders + dispatch)
    //   • production_operator   → production / planning (production also gets approve, above)
    //   • closing_data_poster   → planning / material_consumption (stock closing, company job orders)
    // Out-of-scope, delete and approve all fall through to the per-user module_permissions
    // check below, which denies them (strict roles carry no module_permissions rows).
    const grantsWithinScope = (modules: string[]): boolean =>
      modules.includes(module) && permission !== 'delete' && permission !== 'approve';

    // QA Inspector: view + create ONLY within the QA module (the inspection entry
    // form needs view to render and create to save). GRANT-ONLY (additive) like the
    // strict roles below — out-of-scope falls through, never vetoes another role.
    if (
      roles.some(r => r.role === 'qa_inspector') &&
      module === 'qa' &&
      (permission === 'view' || permission === 'create')
    ) {
      return true;
    }

    // Gate Pass Manager: read-only within Store Pass (tracking / reconciliation). Making
    // or cancelling store passes stays with the store pass roles, checked in the database.
    if (roles.some(r => r.role === 'gate_pass_manager') && module === 'store_pass' && permission === 'view') {
      return true;
    }
    // Gate Security: view within Gate Pass so the Gate Check page renders. Its one
    // action (count / mark Out / hold) is checked by role in the database, not here.
    if (roles.some(r => r.role === 'gate_security') && module === 'gate_pass' && permission === 'view') {
      return true;
    }
    // Gate Pass type managers: view within Gate Pass. Their approve right is per pass
    // type (canApproveGatePassType in lib/gatePass), never the module-wide 'approve'.
    if (roles.some(r => GATE_PASS_TYPE_MANAGER_ROLES.includes(r.role)) && module === 'gate_pass' && permission === 'view') {
      return true;
    }

    // Purchase Request roles: view within Purchase so the Purchase Requests page renders.
    // Their approval is per category (hasPurchaseCategoryPermission) and checked in the database.
    if (roles.some(r => PURCHASE_REQUEST_ROLE_CATEGORY[r.role]) && module === 'purchase' && permission === 'view') return true;
    if (roles.some(r => r.role === 'dispatch_operator') && grantsWithinScope(['sales', 'domestic'])) return true;
    if (roles.some(r => r.role === 'sales_order_manager') && grantsWithinScope(['sales', 'domestic'])) return true;
    if (roles.some(r => r.role === 'production_operator') && grantsWithinScope(['production', 'planning'])) return true;
    if (roles.some(r => r.role === 'closing_data_poster') && grantsWithinScope(['planning', 'material_consumption'])) return true;

    // Distributor Order Management roles — grants within the 'distributor' module only.
    //   • distributor_sales   → view / create / edit (orders, customers, own catalog). No approve/delete.
    //   • distributor_manager → view / create / edit / approve (approve/reject orders). No delete.
    //   • distributor_admin   → full control (incl. delete) of the distributor module.
    if (module === 'distributor') {
      if (roles.some(r => r.role === 'distributor_admin')) return true;
      if (roles.some(r => r.role === 'distributor_manager')) return permission !== 'delete';
      if (roles.some(r => r.role === 'distributor_sales')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
    }

    // Online Sales access tiers — grants within the 'online_sales' module only.
    //   • online_sales_admin   → full control incl. delete and approve.
    //   • online_sales_manager → view / create / edit / approve (no delete).
    //   • online_sales_agent   → view / create / edit (no delete, no approve).
    if (module === 'online_sales') {
      if (roles.some(r => r.role === 'online_sales_admin')) return true;
      if (roles.some(r => r.role === 'online_sales_manager')) return permission !== 'delete';
      if (roles.some(r => r.role === 'online_sales_agent')) {
        return permission === 'view' || permission === 'create' || permission === 'edit';
      }
    }

    // Generic per-module tiers (export / master data / HR / WIP / rejections / performance /
    // floor inventory / fixed assets / 5S / hourly production / R&D / CRM / marketing).
    // GRANT-ONLY (additive) like the strict operational roles above: an out-of-scope tier
    // falls through instead of returning false, so one tier can never veto another tier the
    // same user also holds. Delete always falls through (reserved for super admin).
    // Projects Super Manager: view / create / edit / approve across all projects, never delete.
    if (module === 'projects' && permission !== 'delete' && roles.some(r => r.role === 'projects_super_manager')) {
      return true;
    }

    // QA Super Manager: view / create / edit / approve across QA, never delete.
    if (module === 'qa' && permission !== 'delete' && roles.some(r => r.role === 'qa_super_manager')) {
      return true;
    }

    for (const r of roles) {
      const tier = MODULE_TIER_ROLES[r.role];
      if (!tier || tier.module !== module) continue;
      if (tier.tier === 'manager' && permission !== 'delete') return true;
      if (tier.tier === 'officer' && (permission === 'view' || permission === 'create' || permission === 'edit')) return true;
      if (tier.tier === 'viewer' && permission === 'view') return true;
    }

    // Staff Gate Pass Approver: view only in HR; approving staff passes is checked by
    // role on the gate pass pages and in the database. Grant-only, so an HR tier the
    // same user also holds keeps its own rights.
    if (module === 'hr' && permission === 'view' && roles.some(r => r.role === 'staff_gate_pass_approver')) {
      return true;
    }

    const perm = modulePermissions.find(p => p.module_name === module);
    if (!perm) return false;
    
    switch (permission) {
      case 'view': return perm.can_view;
      case 'create': return perm.can_create;
      case 'edit': return perm.can_edit;
      case 'delete': return perm.can_delete;
      case 'approve': return perm.can_approve;
      default: return false;
    }
  };

  const hasPurchaseCategoryPermission = (
    category: PurchaseCategoryPermission['category'], 
    permission: 'view' | 'create' | 'approve'
  ): boolean => {
    // Super admin has all permissions
    if (roles.some(r => r.role === 'super_admin')) return true;

    // Purchase manager approves across all purchase categories. Granted up-front so a
    // more-restrictive role the same user also holds (e.g. accounting_officer, which
    // grants only view/create below) cannot veto the manager's approval rights.
    if (roles.some(r => r.role === 'purchase_manager')) return true;

    // Purchase Request roles: an Officer views its category; an Approver also approves it.
    // GRANT-ONLY so another role the user holds can still grant more.
    if (roles.some(r => {
      const pr = PURCHASE_REQUEST_ROLE_CATEGORY[r.role];
      return pr && pr.category === category && (permission === 'view' || (permission === 'approve' && pr.approver));
    })) return true;

    // Purchase QC Inspector records the inspection (create) and signs it off (approve)
    // for incoming material — both actions on the Quality Inspection page.
    if (roles.some(r => r.role === 'purchase_qc_inspector')) {
      return permission === 'view' || permission === 'create' || permission === 'approve';
    }

    // Accounting Officer: operates the full Purchase module — allow viewing & creating across
    // all purchase categories (so the Purchase Invoices list and Goods Receipt category flows
    // work). Approval stays reserved for purchase managers.
    if (roles.some(r => r.role === 'accounting_officer')) {
      return permission === 'view' || permission === 'create';
    }

    // Purchase officer operates across all purchase categories so they can create POs in
    // any category, but cannot approve (manager handled above).
    if (roles.some(r => r.role === 'purchase_officer')) {
      return permission === 'view' || permission === 'create';
    }

    const perm = purchaseCategoryPermissions.find(p => p.category === category);
    if (!perm) return false;
    
    switch (permission) {
      case 'view': return perm.can_view;
      case 'create': return perm.can_create;
      case 'approve': return perm.can_approve;
      default: return false;
    }
  };

  // Check if user can access a specific route (for roles with route-level restrictions)
  const canAccessRoute = (route: string): boolean => {
    // Super admin has all access
    if (roles.some((r) => r.role === 'super_admin')) return true;

    // The notifications inbox only ever shows the user's own notifications, so
    // every role — including strictly route-locked ones — may open it.
    if (route === '/notifications') return true;

    // Every signed-in user may open their own profile and account settings.
    if (route === '/profile' || route === '/account-settings') return true;

    // The help desk submit page only ever shows the user's own tickets, so
    // every role may open it. Ticket management is gated separately via the
    // /helpdesk/manage route's requiredRoles guard (super_admin + helpdesk_manager).
    if (route === '/helpdesk') return true;

    // My Gate Passes: a staff member raising and following their own company work
    // passes. The pages only ever show the passes of the staff record linked to the
    // login, so every role may open them (the database checks the link on every write).
    if (route === '/my-gate-pass' || route.startsWith('/my-gate-pass/')) return true;

    // My Travel Vouchers: the trip fuel vouchers of the staff record linked to the
    // login, to print for the cashier. Same rule as My Gate Passes.
    if (route === '/my-travel-vouchers') return true;

    // My Purchase Requests: anyone raises their own purchase requests and follows
    // them; department heads approve their department's here. The pages only act
    // through the purchase_request_* database functions, which check who may do what.
    if (route === '/my-purchase-requests' || route.startsWith('/my-purchase-requests/')) return true;

    // Admin & Facilities self service: anyone raises supply requests from the admin
    // store, sees the office assets and SIM they hold, and reports an equipment fault.
    // The pages only act through facilities_* database functions, which check who may do what.
    if (route === '/my-supply-requests' || route.startsWith('/my-supply-requests/')) return true;
    if (route === '/my-assets' || route === '/report-fault') return true;

    // Explicit per-role route denials take precedence (e.g. hide P&L / Balance Sheet from a tier)
    if (
      roles.some((r) =>
        ROLE_ROUTE_DENY[r.role]?.some(
          (denied) => route === denied || route.startsWith(denied + '/')
        )
      )
    ) {
      return false;
    }

    // Strict-locked roles confine the user to their explicit route whitelist even if the user
    // also holds a flexible role. When the user also holds another route-restricted role
    // (e.g. pettycash_handler alongside dispatch_operator), confine to the UNION of all their
    // restricted whitelists — a flexible role (no whitelist) still cannot widen this.
    // A hard-restricted role WITHOUT an explicit whitelist (accounting_manager /
    // accounting_officer / qa_manager / …) joins the union with the routes of its own
    // module scope, mirroring how canAccessModule unions module scopes above.
    // Per-user module permission rows (an explicit admin grant) also join the union with
    // their module's routes — but ONLY for modules outside every strict role's own scope,
    // matching canAccessModule: inside a strict role's scope its whitelist stays the only
    // authority, so permission rows can never widen a strict role's own module.
    const strictRoles = roles.filter((r) => STRICT_LOCKED_ROLES.has(r.role));
    if (strictRoles.length > 0) {
      const scopedRoles = roles.filter(
        (r) => ROLE_ROUTE_RESTRICTIONS[r.role] || HARD_RESTRICTED_MODULE_ROLES.has(r.role)
      );
      if (
        scopedRoles.some((r) => {
          const allowedRoutes = ROLE_ROUTE_RESTRICTIONS[r.role] ?? implicitRouteWhitelist(r.role);
          return allowedRoutes.some((allowed) => route === allowed || route.startsWith(allowed + '/'));
        })
      ) {
        return true;
      }
      const strictScope = new Set(strictRoles.flatMap((r) => ROLE_MODULE_ACCESS[r.role] ?? []));
      return modulePermissions.some((p) => {
        if (!p.can_view || strictScope.has(p.module_name)) return false;
        const prefix = MODULE_ROUTE_PREFIXES[p.module_name];
        return !!prefix && (route === prefix || route.startsWith(prefix + '/'));
      });
    }

    const restrictedRoles = roles.filter((r) => ROLE_ROUTE_RESTRICTIONS[r.role]);

    if (restrictedRoles.length === 0) {
      return true;
    }

    const hasFlexibleRole = roles.some((r) => !ROLE_ROUTE_RESTRICTIONS[r.role]);

    // If the user has any unrestricted role, don't let a secondary restricted role hide valid pages.
    if (hasFlexibleRole) {
      return true;
    }

    // Users with only restricted roles can access the union of their explicitly allowed routes.
    return restrictedRoles.some((r) => {
      const allowedRoutes = ROLE_ROUTE_RESTRICTIONS[r.role];
      return allowedRoutes.some((allowed) => route === allowed || route.startsWith(allowed + '/'));
    });

    // No route restrictions for this role - fall back to module access
  };

  return (
    <AuthContext.Provider value={{
      user,
      roles,
      modulePermissions,
      purchaseCategoryPermissions,
      isLoading,
      isAuthenticated: !!user,
      login,
      logout,
      refreshUser,
      hasRole,
      hasModulePermission,
      hasPurchaseCategoryPermission,
      canAccessModule,
      canAccessRoute,
      canViewPrices,
      getDistributorScope
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
