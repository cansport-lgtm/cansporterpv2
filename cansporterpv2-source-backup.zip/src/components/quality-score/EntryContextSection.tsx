import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  QS_ENTRY_SELECT, QsEntry, applySelection, useQsSelectionOptions,
} from "./qsShared";

interface Lookup { id: string; name: string; }

export interface QsEntryContext {
  date: string;
  setDate: (v: string) => void;
  departmentId: string;
  setDepartmentId: (v: string) => void;
  productId: string; // "none" when not set
  setProductId: (v: string) => void;
  gradeId: string; // "none" when not set
  setGradeId: (v: string) => void;
  ready: boolean;
  entry: QsEntry | null | undefined;
  entryLoading: boolean;
  refetchEntry: () => void;
  entryQueryKey: (string | null)[];
  findOrCreateEntry: () => Promise<string>;
}

// Both inspector entry pages score against the same context: date + department
// (+ optional product/grade). The qs_score_entries row is created lazily on first submit.
export function useQsEntryContext(): QsEntryContext {
  const { user } = useAuth();
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [departmentId, setDepartmentId] = useState("");
  const [productId, setProductId] = useState("none");
  const [gradeId, setGradeId] = useState("none");

  const ready = !!date && !!departmentId;
  const entryQueryKey = [
    "qs-entry-context", date, departmentId,
    productId === "none" ? null : productId,
    gradeId === "none" ? null : gradeId,
  ];

  const { data: entry, isLoading: entryLoading, refetch: refetchEntry } = useQuery({
    queryKey: entryQueryKey,
    enabled: ready,
    queryFn: async () => {
      let q = (supabase as any)
        .from("qs_score_entries")
        .select(QS_ENTRY_SELECT)
        .eq("entry_date", date)
        .eq("department_id", departmentId);
      q = productId !== "none" ? q.eq("product_id", productId) : q.is("product_id", null);
      q = gradeId !== "none" ? q.eq("grade_id", gradeId) : q.is("grade_id", null);
      const { data, error } = await q.limit(1);
      if (error) throw error;
      return (data?.[0] ?? null) as QsEntry | null;
    },
  });

  const findOrCreateEntry = async (): Promise<string> => {
    if (entry?.id) return entry.id;
    const { data, error } = await (supabase as any)
      .from("qs_score_entries")
      .insert({
        entry_date: date,
        department_id: departmentId,
        product_id: productId !== "none" ? productId : null,
        grade_id: gradeId !== "none" ? gradeId : null,
        created_by: user?.id ?? null,
      })
      .select("id")
      .single();
    if (error) throw error;
    return data.id as string;
  };

  return {
    date, setDate, departmentId, setDepartmentId,
    productId, setProductId, gradeId, setGradeId,
    ready, entry, entryLoading, refetchEntry, entryQueryKey, findOrCreateEntry,
  };
}

// Active grades, narrowed to the Selection Master picks
export function useQsGradeOptions() {
  const { data: selections = [] } = useQsSelectionOptions();
  const { data: grades = [] } = useQuery({
    queryKey: ["qs-lookup-grades"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("grades").select("id, name").eq("is_active", true).order("name");
      if (error) throw error;
      return data as Lookup[];
    },
  });
  return applySelection(grades, selections, "grade");
}

// hideGrade: the page picks a grade per ball instead (Ball Quality multi-ball entry)
export function EntryContextSection({
  ctx, hideGrade = false,
}: { ctx: QsEntryContext; hideGrade?: boolean }) {
  const { data: selections = [] } = useQsSelectionOptions();
  const gradeOptions = useQsGradeOptions();

  const { data: departments = [] } = useQuery({
    queryKey: ["qs-lookup-departments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("production_departments").select("id, name").eq("is_active", true).order("name");
      if (error) throw error;
      return data as Lookup[];
    },
  });

  const { data: products = [] } = useQuery({
    queryKey: ["qs-lookup-products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products").select("id, name").eq("is_active", true).order("name");
      if (error) throw error;
      return data as Lookup[];
    },
  });

  const departmentOptions = applySelection(departments, selections, "department");
  const productOptions = applySelection(products, selections, "product");

  return (
    <Card>
      <CardContent className="p-6">
        <div className={`grid gap-4 sm:grid-cols-2 ${hideGrade ? "lg:grid-cols-3" : "lg:grid-cols-4"}`}>
          <div>
            <Label className="text-xs">Date</Label>
            <Input type="date" value={ctx.date} onChange={(e) => ctx.setDate(e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Department</Label>
            <Select value={ctx.departmentId} onValueChange={ctx.setDepartmentId}>
              <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
              <SelectContent>
                {departmentOptions.map((d) => (
                  <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Product (optional)</Label>
            <Select value={ctx.productId} onValueChange={ctx.setProductId}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">All / not specified</SelectItem>
                {productOptions.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {!hideGrade && (
            <div>
              <Label className="text-xs">Grade (optional)</Label>
              <Select value={ctx.gradeId} onValueChange={ctx.setGradeId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">All / not specified</SelectItem>
                  {gradeOptions.map((g) => (
                    <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
