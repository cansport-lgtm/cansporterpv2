import { useState } from "react";
import { ERPLayout } from "@/components/layout/ERPLayout";
import { MetricCard } from "@/components/shared/MetricCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Package, TrendingDown, AlertTriangle, BarChart3 } from "lucide-react";
import { format, startOfWeek, endOfWeek, subDays } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MATERIAL_VALUE_CATEGORIES, type MaterialValueCategory } from "@/lib/materialValueCategory";

// A raw-material-level value tier filter ("all" or one of the enum values).
type ValueTierFilter = MaterialValueCategory | "all";

// Shared predicate applied wherever raw-material rows are aggregated, so the
// Value Tier filter behaves identically across every tab on this page.
function matchesValueTier(
  category: MaterialValueCategory | null | undefined,
  filter: ValueTierFilter
): boolean {
  return filter === "all" || category === filter;
}

export default function ConsumptionEfficiencyDashboard() {
  const today = new Date();
  const weekStart = startOfWeek(today, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
  const [valueTierFilter, setValueTierFilter] = useState<ValueTierFilter>("all");

  // Fetch raw materials count
  const { data: rawMaterials } = useQuery({
    queryKey: ["consumption-raw-materials-count"],
    queryFn: async () => {
      const { count } = await supabase
        .from("consumption_raw_materials")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true);
      return count || 0;
    },
  });

  // Fetch BOM count
  const { data: bomCount } = useQuery({
    queryKey: ["consumption-bom-count"],
    queryFn: async () => {
      const { count } = await supabase
        .from("consumption_bom")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true);
      return count || 0;
    },
  });

  // Fetch today's stock closing
  const { data: todayClosing } = useQuery({
    queryKey: ["consumption-today-closing", format(today, "yyyy-MM-dd"), valueTierFilter],
    queryFn: async () => {
      const { data } = await supabase
        .from("consumption_stock_closing")
        .select(`
          *,
          raw_material:consumption_raw_materials(name, unit, value_category)
        `)
        .eq("closing_date", format(today, "yyyy-MM-dd"));
      return (data || []).filter((item: any) =>
        matchesValueTier(item.raw_material?.value_category, valueTierFilter)
      );
    },
  });

  // Fetch weekly consumption summary
  const { data: weeklyConsumption } = useQuery({
    queryKey: ["consumption-weekly-summary", format(weekStart, "yyyy-MM-dd"), valueTierFilter],
    queryFn: async () => {
      const { data } = await supabase
        .from("consumption_stock_closing")
        .select(`
          raw_material_id,
          actual_consumption,
          raw_material:consumption_raw_materials(name, unit, value_category)
        `)
        .gte("closing_date", format(weekStart, "yyyy-MM-dd"))
        .lte("closing_date", format(weekEnd, "yyyy-MM-dd"));

      const filtered = (data || []).filter((item: any) =>
        matchesValueTier(item.raw_material?.value_category, valueTierFilter)
      );

      // Group by material
      const grouped: Record<string, { name: string; unit: string; total: number }> = {};
      filtered.forEach((item: any) => {
        const id = item.raw_material_id;
        if (!grouped[id]) {
          grouped[id] = {
            name: item.raw_material?.name || "Unknown",
            unit: item.raw_material?.unit || "kg",
            total: 0,
          };
        }
        grouped[id].total += Number(item.actual_consumption) || 0;
      });
      return Object.values(grouped);
    },
  });

  // Fetch consumption variance data (7 days)
  const { data: varianceData } = useQuery({
    queryKey: ["consumption-variance", format(today, "yyyy-MM-dd"), valueTierFilter],
    queryFn: async () => {
      // Get production entries
      const { data: production } = await supabase
        .from("consumption_production_entry")
        .select(`
          product_id,
          quantity_produced,
          entry_date
        `)
        .gte("entry_date", format(subDays(today, 7), "yyyy-MM-dd"))
        .lte("entry_date", format(today, "yyyy-MM-dd"));

      // Get BOM data
      const { data: bom } = await supabase
        .from("consumption_bom")
        .select(`
          product_id,
          raw_material_id,
          standard_quantity,
          raw_material:consumption_raw_materials(name, unit, value_category)
        `)
        .eq("is_active", true);

      // Calculate standard consumption
      const standardByMaterial: Record<string, { name: string; unit: string; standard: number }> = {};
      production?.forEach((prod: any) => {
        const bomItems =
          bom?.filter(
            (b: any) =>
              b.product_id === prod.product_id &&
              matchesValueTier(b.raw_material?.value_category, valueTierFilter)
          ) || [];
        bomItems.forEach((b: any) => {
          const id = b.raw_material_id;
          if (!standardByMaterial[id]) {
            standardByMaterial[id] = {
              name: b.raw_material?.name || "Unknown",
              unit: b.raw_material?.unit || "kg",
              standard: 0,
            };
          }
          standardByMaterial[id].standard += Number(b.standard_quantity) * Number(prod.quantity_produced);
        });
      });

      // Get actual consumption
      const { data: closing } = await supabase
        .from("consumption_stock_closing")
        .select("raw_material_id, actual_consumption")
        .gte("closing_date", format(subDays(today, 7), "yyyy-MM-dd"))
        .lte("closing_date", format(today, "yyyy-MM-dd"));

      const actualByMaterial: Record<string, number> = {};
      closing?.forEach((c: any) => {
        actualByMaterial[c.raw_material_id] = (actualByMaterial[c.raw_material_id] || 0) + Number(c.actual_consumption);
      });

      // Calculate variance
      return Object.entries(standardByMaterial).map(([id, data]) => ({
        name: data.name,
        unit: data.unit,
        standard: data.standard,
        actual: actualByMaterial[id] || 0,
        variance: (actualByMaterial[id] || 0) - data.standard,
        variancePct: data.standard > 0 ? (((actualByMaterial[id] || 0) - data.standard) / data.standard) * 100 : 0,
      })).sort((a, b) => Math.abs(b.variancePct) - Math.abs(a.variancePct));
    },
  });

  // Category-wise consumption breakdown
  const { data: categoryBreakdown } = useQuery({
    queryKey: ["consumption-category-breakdown", format(weekStart, "yyyy-MM-dd"), valueTierFilter],
    queryFn: async () => {
      const { data } = await supabase
        .from("consumption_stock_closing")
        .select(`
          actual_consumption,
          raw_material:consumption_raw_materials(category, unit, value_category)
        `)
        .gte("closing_date", format(weekStart, "yyyy-MM-dd"))
        .lte("closing_date", format(weekEnd, "yyyy-MM-dd"));

      const filtered = (data || []).filter((item: any) =>
        matchesValueTier(item.raw_material?.value_category, valueTierFilter)
      );

      // Group by category
      const grouped: Record<string, { category: string; total: number; unit: string }> = {};
      filtered.forEach((item: any) => {
        const category = item.raw_material?.category || "Uncategorized";
        if (!grouped[category]) {
          grouped[category] = {
            category,
            total: 0,
            unit: item.raw_material?.unit || "kg",
          };
        }
        grouped[category].total += Number(item.actual_consumption) || 0;
      });

      return Object.values(grouped).sort((a, b) => b.total - a.total);
    },
  });

  const totalActualConsumption = todayClosing?.reduce(
    (sum, item: any) => sum + (Number(item.actual_consumption) || 0),
    0
  ) || 0;

  const highVarianceCount = varianceData?.filter((v) => Math.abs(v.variancePct) > 10).length || 0;
  const totalStandard = varianceData?.reduce((sum, v) => sum + v.standard, 0) || 0;
  const totalActual = varianceData?.reduce((sum, v) => sum + v.actual, 0) || 0;
  const overallVariancePct = totalStandard > 0 ? ((totalActual - totalStandard) / totalStandard) * 100 : 0;

  return (
    <ERPLayout>
      <div className="space-y-6">
        <div className="page-header">
          <div>
            <h1 className="page-title">Consumption Efficiency Dashboard</h1>
            <p className="page-description">Analyze material consumption variance and identify material loss</p>
          </div>
          <div className="flex gap-2 items-center">
            <Select
              value={valueTierFilter}
              onValueChange={(v) => setValueTierFilter(v as ValueTierFilter)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All value tiers</SelectItem>
                {MATERIAL_VALUE_CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Raw Materials"
            value={rawMaterials || 0}
            icon={Package}
            description="Active materials tracked"
          />
          <MetricCard
            title="BOM Standards"
            value={bomCount || 0}
            icon={BarChart3}
            description="Consumption recipes"
          />
          <MetricCard
            title="Today's Consumption"
            value={`${totalActualConsumption.toFixed(2)} kg`}
            icon={TrendingDown}
            description="Actual material used"
          />
          <MetricCard
            title="High Variance Items"
            value={highVarianceCount}
            icon={AlertTriangle}
            trend={highVarianceCount > 0 ? { value: 10, isPositive: false } : undefined}
            description="Materials with >10% variance"
          />
        </div>

        {/* Overall Efficiency Summary */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Standard Consumption (7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalStandard.toFixed(2)} kg</div>
              <p className="text-xs text-muted-foreground">Based on BOM × Production</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Actual Consumption (7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalActual.toFixed(2)} kg</div>
              <p className="text-xs text-muted-foreground">Opening + Receipt - Closing</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Overall Variance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${overallVariancePct > 5 ? "text-destructive" : overallVariancePct < -5 ? "text-green-600" : ""}`}>
                {overallVariancePct > 0 ? "+" : ""}{overallVariancePct.toFixed(1)}%
              </div>
              <p className="text-xs text-muted-foreground">
                {overallVariancePct > 0 ? "Over consumption" : overallVariancePct < 0 ? "Under consumption" : "On target"}
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="variance" className="space-y-4">
          <TabsList>
            <TabsTrigger value="variance">Variance Analysis (7 Days)</TabsTrigger>
            <TabsTrigger value="category">Category Breakdown</TabsTrigger>
            <TabsTrigger value="weekly">Weekly Summary</TabsTrigger>
            <TabsTrigger value="today">Today's Closing</TabsTrigger>
          </TabsList>

          <TabsContent value="variance">
            <Card>
              <CardHeader>
                <CardTitle>Material Consumption Variance Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Material</TableHead>
                      <TableHead className="text-right">Standard Qty</TableHead>
                      <TableHead className="text-right">Actual Qty</TableHead>
                      <TableHead className="text-right">Variance</TableHead>
                      <TableHead className="text-right">Variance %</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {varianceData?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground">
                          No variance data available. Add production entries and stock closings.
                        </TableCell>
                      </TableRow>
                    ) : (
                      varianceData?.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell className="text-right">{item.standard.toFixed(2)} {item.unit}</TableCell>
                          <TableCell className="text-right">{item.actual.toFixed(2)} {item.unit}</TableCell>
                          <TableCell className="text-right">
                            <span className={item.variance > 0 ? "text-destructive" : "text-green-600"}>
                              {item.variance > 0 ? "+" : ""}{item.variance.toFixed(2)} {item.unit}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={Math.abs(item.variancePct) > 10 ? "text-destructive font-semibold" : ""}>
                              {item.variancePct > 0 ? "+" : ""}{item.variancePct.toFixed(1)}%
                            </span>
                          </TableCell>
                          <TableCell>
                            {Math.abs(item.variancePct) > 10 ? (
                              <Badge variant="destructive">High Loss</Badge>
                            ) : Math.abs(item.variancePct) > 5 ? (
                              <Badge variant="secondary">Moderate</Badge>
                            ) : (
                              <Badge variant="outline">Normal</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="category">
            <Card>
              <CardHeader>
                <CardTitle>Category-wise Consumption ({format(weekStart, "MMM d")} - {format(weekEnd, "MMM d, yyyy")})</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-right">Total Consumption</TableHead>
                      <TableHead>Unit</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryBreakdown?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                          No consumption data for this week
                        </TableCell>
                      </TableRow>
                    ) : (
                      categoryBreakdown?.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{item.category}</TableCell>
                          <TableCell className="text-right">{item.total.toFixed(2)}</TableCell>
                          <TableCell>{item.unit}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="weekly">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Consumption Summary ({format(weekStart, "MMM d")} - {format(weekEnd, "MMM d, yyyy")})</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Material</TableHead>
                      <TableHead className="text-right">Total Consumption</TableHead>
                      <TableHead>Unit</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {weeklyConsumption?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                          No consumption data for this week
                        </TableCell>
                      </TableRow>
                    ) : (
                      weeklyConsumption?.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell className="text-right">{item.total.toFixed(2)}</TableCell>
                          <TableCell>{item.unit}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="today">
            <Card>
              <CardHeader>
                <CardTitle>Today's Stock Closing ({format(today, "MMM d, yyyy")})</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Material</TableHead>
                      <TableHead className="text-right">Opening</TableHead>
                      <TableHead className="text-right">Receipts</TableHead>
                      <TableHead className="text-right">Closing</TableHead>
                      <TableHead className="text-right">Consumption</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {todayClosing?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground">
                          No closing entries for today
                        </TableCell>
                      </TableRow>
                    ) : (
                      todayClosing?.map((item: any) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.raw_material?.name}</TableCell>
                          <TableCell className="text-right">{Number(item.opening_quantity).toFixed(2)} {item.raw_material?.unit}</TableCell>
                          <TableCell className="text-right">{Number(item.receipt_quantity).toFixed(2)} {item.raw_material?.unit}</TableCell>
                          <TableCell className="text-right">{Number(item.closing_quantity).toFixed(2)} {item.raw_material?.unit}</TableCell>
                          <TableCell className="text-right font-semibold">{Number(item.actual_consumption).toFixed(2)} {item.raw_material?.unit}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ERPLayout>
  );
}
